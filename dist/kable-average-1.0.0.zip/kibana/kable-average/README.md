# Example plugin for Kable

This project provides a sample plugin for extending Kable, itself a plugin of Kibana.

### Functions
#### Average
Super dumb average against Kable provided columns
